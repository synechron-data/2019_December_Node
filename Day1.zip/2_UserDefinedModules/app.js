// const lib = require('./lib.js');
// console.log(lib);

// console.log(lib.firstname);
// console.log(lib.lastname);

// lib.log("Hi from App");

// var e1 = new lib.Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// const logger1 = require('./logger1.js');
// const logger2 = require('./logger1.js');
// const logger3 = require('./logger1.js');

// console.log(logger1 === logger2);

// const logger1 = require('./logger1');

// const logger1 = require('./logger');

const loggerFactory = require('./loggerFactory');

let dbLogger = loggerFactory.DBLFactory.getLogger();
let fileLogger = loggerFactory.FLFactory.getLogger();

dbLogger.log("Hello");
fileLogger.log("Hello");