const readline = require('readline');
// console.log(readline);

var rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Enter a number: ", (n1) => {
    let num1 = parseInt(n1);
    rl.question("Enter a number: ", (n2) => {
        let num2 = parseInt(n2);
        let sum = num1 + num2;
        console.log("Result is: ", sum);
        rl.close();
    });
});

// rl.question("Enter a number: ", (input) => {
//     console.log("You enetered: ", input);
//     rl.close();
// });

// console.log("-------------- Last Line --------------");