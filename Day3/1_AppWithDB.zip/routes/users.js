var express = require('express');
var router = express.Router();

const userCtrl = require('../controllers/user-controller');

router.get('/', userCtrl.index);

router.get('/details/:userid', userCtrl.details);

router.get('/create', userCtrl.create_get);

router.post('/create', userCtrl.create_post);

router.get('/edit/:userid', userCtrl.edit_get);

router.post('/edit/:userid', userCtrl.edit_post);

router.get('/delete/:userid', userCtrl.delete_get);

router.post('/delete/:userid', userCtrl.delete_post);

module.exports = router;
