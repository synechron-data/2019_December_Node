$(document).ready(function () {
    window.sessionStorage.clear();

    $.post('/account/getToken', { username: 'manish', password: 'manish' },
        function (data, status) {
            window.sessionStorage.setItem('tk', data.token);
        });

    $("#btnLoad").click(function (e) {
        $("#ut_body").empty();

        $.ajax({
            url: '/api/users',
            type: 'GET',
            dataType: 'json',
            success: function (resData) {
                if (resData.data) {
                    var tmpl = $.templates("#userRowTemplate");
                    var html = tmpl.render(resData.data);
                    console.log(html);
                    $("#ut_body").append(html);
                }
            },
            error: function (err) {
                console.log(err);
            },
            beforeSend: function (xhr) {
                xhr.setRequestHeader('x-access-token', window.sessionStorage.getItem('tk'));
            }
        });
    });
});