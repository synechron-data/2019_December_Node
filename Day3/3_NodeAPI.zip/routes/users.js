var express = require('express');
var router = express.Router();

const accCtrl = require('../controllers/account-controller');
const userCtrl = require('../controllers/user-controller');

router.use(accCtrl.isAuthenticated);

router.get('/', userCtrl.index);

module.exports = router;
